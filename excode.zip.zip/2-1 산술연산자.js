let rlSync = require('readline-sync');
let n1 = rlSync.question('First number? ');
let n2 = rlSync.question('Second number? ');

let sum = n1 + n2;
let sub = n1 - n2;
let mul = n1 * n2;
let div = n1 / n2;

console.log(`${n1} + ${n2} = ${sum}`);
console.log(`${n1} - ${n2} = ${sub}`);
console.log(`${n1} * ${n2} = ${mul}`);
console.log(`${n1} / ${n2} = ${div}`);

// 15 - 5 * (7 + 2 * 3)^2
const result1 = 15 - 5 * ((7 + 2 * 3) ** 2);
console.log(result1);

// 5 * (2 + (5 - 3) / 4) * 128
const result2 = 5 * (2 + (5 - 3) / 4) * 128;
console.log(result2);

// ((3^3 - 2) % 5 + 2)^2
const result3 = (((3 ** 3 - 2) % 5) + 2) ** 2;
console.log(result3);