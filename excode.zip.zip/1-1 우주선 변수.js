// 우주선 연습문제

let Name = "Hope";
const speed = 17500;
const Km = 0.621;
const MarsKm = 225000000;
const MoonKm = 384400;
let SpaceshipKg = 5500;
let Kg = 1100;

let marsHours = (MarsKm * Km) / speed;

let moonHours = (MoonKm * Km) / speed;

let totalKg = SpaceshipKg + Kg;

console.log(`우주선 ${Name}는 화성까지 ${marsHours.toFixed(2)}시간`);
console.log(`우주선 ${Name}는 달까지 ${moonHours.toFixed(2)}시간`);
console.log(`우주선 ${Name}의 발사무게 ${totalKg}kg`);