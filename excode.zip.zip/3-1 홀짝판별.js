function number(n) {
  if (n % 2 === 0) {
    return `${n}은 짝수`;
  }
  return `${n}은 홀수`;
}

console.log(number(1));
console.log(number(2));