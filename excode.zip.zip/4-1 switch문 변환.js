// if else 문을 사용하여 변환
switch (browser) {
  case 'Edge':
    console.log("Edge를 사용하고 계시네요");
    break;
  case 'Chrome':
  case 'Firefox':
  case 'Safari':
  case 'Opera':
    console.log('지원하는 브라우저 입니다');
    break;
  default:
    console.log('good Luck!');
}


if (browser === 'Edge') {
  console.log("Edge를 사용하고 계시네요");
} else if (
  browser === 'Chrome' ||
  browser === 'Firefox' ||
  browser === 'Safari' ||
  browser === 'Opera'
) {
  console.log('지원하는 브라우저 입니다');
} else {
  console.log('good Luck!');
}
