const max = (n1, n2) => (n1 > n2 ? n1 : n2);

const factorial = (n) => {
  if (n <= 1) return 1;
  return n * factorial(n - 1);
};

const pibo = (n) => {
  if (n <= 0) return 0;
  if (n <= 2) return 1;
  return pibo(n - 1) + pibo(n - 2);
};

const calc = (n1, n2, operator) => {
  switch (operator) {
    case '+':
      return n1 + n2;
    case '-':
      return n1 - n2;
    case '*':
      return n1 * n2;
    case '/':
      return n2 !== 0 ? n1 / n2 : '0으로 나누기 불가능';
    default:
      return '+, -, *, / 중 하나 입력';
  }
};

console.log(max(2, 5));
console.log(factorial(3));
console.log(pibo(6));

console.log(calc(3, 5, '+'));
console.log(calc(10, 4, '-'));
console.log(calc(4, 6, '*'));
console.log(calc(9, 3, '/'));