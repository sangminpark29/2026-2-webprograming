const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("구구단 숫자 입력: ", (input) => {
  let dan = parseInt(input);

  if (isNaN(dan) || dan < 1 || dan > 9) {
    console.log("1~9 숫자 입력");
  } else {
    console.log(`--- ${dan}단 ---`);
    for (let i = 1; i <= 9; i++) {
      console.log(`${dan} * ${i} = ${dan * i}`);
    }
  }

  rl.close();
});


// 구구단 전부 출력
for (let i = 1; i <= 9; i++) {
  for (let j = 1; j <= 9; j++) {
    console.log(`${i} * ${j} = ${i * j}`);
  }
}

