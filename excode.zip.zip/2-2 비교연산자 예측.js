console.log(10 > 5); // true
console.log(10 === "10"); // false
console.log(10 == "10"); // true
console.log(5 >= 5); // true
console.log(3 != "3"); // false
console.log(3 !== "3"); // true
console.log(10 > 5 && 3 < 2); // false
console.log(10 > 5 || 3 < 2); // true


console.log("apple" > "banana"); // false
console.log(5 > 3 === true); // true

const a = 10;
const b = "10";
console.log(a == b && a !== b); // true

const x = 20;
console.log(x >= 10 && x <= 20); // true
