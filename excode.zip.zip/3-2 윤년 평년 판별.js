function A_Year(year) {
  const B_Year = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);

  if (B_Year) {
    return `${year}년은 윤년`;
  } else {
    return `${year}년은 평년`;
  }
}

console.log(A_Year(2024));
console.log(A_Year(2023));
console.log(A_Year(2000));
console.log(A_Year(1900));